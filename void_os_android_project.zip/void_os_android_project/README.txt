VOID OS 恐怖整蛊演示项目
- 这是虚构的恐怖手机桌面，包含 24 个模拟应用、随机惊吓弹窗和虚构的“微信不存在联系人”。
- 不访问摄像头、麦克风、真实微信、个人文件或网络。
- 正常退出：使用 Android 返回键或系统应用切换界面关闭。
- 本包是 Android Studio/Gradle 项目源码，不是已经编译的 APK。
- 编译 APK：用 Android Studio 打开此文件夹，等待 Gradle 同步，然后 Build > Build APK(s)。
